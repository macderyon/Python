"""
Name: Anderson Nwammadi
Date:-March,20-2019 
Information Structures with Python [MET CS 521] """

"""
Approximating Pi """

print("pi = is ");
    # Approximating Pi
print(4.0*(1.0-1.0/3.0+1.0/5.0-1.0/7.0+1.0/9.0-1.0/11.0));

print("or");
    # Approximating Pi
print(4.0*(1.0-1.0/3.0+1.0/5.0-1.0/7.0+1.0/9.0-1.0/11.0+1.0/13.0-1.0/15.0));

print(" ");