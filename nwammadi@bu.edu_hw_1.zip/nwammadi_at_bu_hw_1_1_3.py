"""
Name: Anderson Nwammadi
Date:-March,20-2019 
Information Structures with Python [MET CS 521] """

"""
(Display a pattern) Write a program that displays the following pattern
[MET CS 521] Information Structures with Python """


def pattern_f():
    return [
            ''.join([ 
                    #Using Conditions statements and for loop to iterating over the sequence for F
                'F' if (col == 0 or col == 1 or row == 0 or row == 2) else' '
                for col in range (7)]) for row in range(5)
    ]

def pattern_u():
    return [
            ''.join([ 
                    #Using Conditions statements and for loop to iterating over the sequence for U
                'U' if ((col == 0 or col == 6) and row<3) or (row==3 and (col ==1 or col == 5)) or (row== 4 and col>1 and col<5) else' '
                for col in range (7)]) for row in range(5)
    ]            
            
def pattern_n():
    return [
            ''.join([ 
                    #Using Conditions statements and for loop to iterating over the sequence for N
                'N' if (col == 0 or col == 1 or col == 6 or col == 7) or (row ==col-1) else' '
                for col in range (8)]) for row in range(5)
    ]          
    #Returns a zip object,iterator of tuples for f,u,n is paired together                 
for f,u,n in zip(pattern_f(),pattern_u(),pattern_n()):
    print(f,u,n)             