"""
Name: Anderson Nwammadi
Date:-March,20-2019 
Information Structures with Python [MET CS 521] 
"""

"""
(Display three diffrent messages) write a program that displays 
welcome to python,welcome to computer science and programing is fun"""

           #Print all items in the list, one by one:
message = [" Welcome to python programing "," Wlcome to Computer Science "," Programming is fun!"]
for y in message:
    print(y)