"""
Name: Anderson Nwammadi
Date:-March,20-2019 
Information Structures with Python [MET CS 521] """


"""
Assign values

Population = 312032486

YearinSec = 365 * 24 * 60 * 60

Birth = yearinSec / 7

Death = yearinSec // 13

Immigrant = yearinSec // 45 """


      # E.g compute year 1,2,3,4,5 = population + 1,2,3,4,5 * birth - death + immigrant
         
print("Population after 1 year is");
     #Current population, year, seconds in a year,  # Births,    # Deaths,   # Immigrants
print(312032486.0+((1.0*31536000.0)/7.0)-((1.0*31536000.0)/13.0)+((1.0*31536000.0)/45.0));

print("Population after 2 years is");
print(312032486.0+((2.0*31536000.0)/7.0)-((2.0*31536000.0)/13.0)+((2.0*31536000.0)/45.0));

print("Population after 3 years is");
print(312032486.0+((3.0*31536000.0)/7.0)-((3.0*31536000.0)/13.0)+((3.0*31536000.0)/45.0));
        
print("Population after 4 years is");
print(312032486.0+((4.0*31536000.0)/7.0)-((4.0*31536000.0)/13.0)+((4.0*31536000.0)/45.0));

print("Population after 5 years is");
print(312032486.0+((5.0*31536000.0)/7.0)-((5.0*31536000.0)/13.0)+((5.0*31536000.0)/45.0));
        
print(" ");