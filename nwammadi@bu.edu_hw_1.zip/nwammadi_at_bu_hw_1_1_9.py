"""
Name: Anderson Nwammadi
Date:-March,20-2019 
Information Structures with Python [MET CS 521] """

"""
(Area and Perimeter of a rectangle) Write a program that displays the area and
the perimeter of a rectangle with the width of 4.5 and height of 7.9 using the 
following formula: are = width X height """

print ("The area of a rectangle with width 4.5 and height 7.9 is")
print (4.5*7.9) # Calculating the area, Area = width * height


print ("The perimeter of the same rectangle is")
print (2*(4.5+7.9)) # Calculating the perimeter, Perimeter = 2 * width + height


print (" ")